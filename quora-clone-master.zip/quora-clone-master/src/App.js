import React from "react";
import Router from "./routes/Router";
// import { Counter } from "./features/counter/Counter";

function App() {
    return (
        <div className="App">
            <Router />
        </div>
    );
}

export default App;
